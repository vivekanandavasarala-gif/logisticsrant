
# LogistiRant — GitHub Pages Site

This is a static site bundle ready for GitHub Pages.

## Quick Deploy (Web UI)

1. Create a new GitHub repository (public): `logistirant` (any name works).
2. Upload the files from this folder: `index.html`, `404.html`, and `README.md`.
3. Go to **Settings → Pages**:
   - **Source**: `Deploy from a branch`
   - **Branch**: `main` (or `master`) / `/ (root)`
4. Click **Save**. In ~30–60 seconds, your site will be live at:
   - `https://<your-username>.github.io/<repo-name>/`

## CLI Deploy (Windows PowerShell)

```powershell
# From a new empty folder on your PC (e.g., C:\logistirant)
git init
git remote add origin https://github.com/<your-username>/<repo-name>.git

# Copy the 3 files into this folder, then:
git add .
git commit -m "Initial commit: LogistiRant static site"
git branch -M main
git push -u origin main

# Enable Pages:
# On GitHub → Settings → Pages → Source = Deploy from a branch, Branch=main, Folder=/ (root)
```

## Optional: Custom Domain (GoDaddy)

- In this repo, add a file named `CNAME` containing your domain (e.g., `logistirant.example.com`).
- On GoDaddy DNS:
  - If using a subdomain like `www.example.com` or `logistirant.example.com` → create a **CNAME** record pointing to `your-username.github.io`.
  - If using the apex/root domain (e.g., `example.com`) → use GoDaddy's guidance for GitHub Pages A/ALIAS/ANAME records per GitHub Docs.
- After DNS propagates, GitHub Pages → **Enforce HTTPS**.

## Notes

- All assets are loaded via CDN (TailwindCSS + FontAwesome). Internet is required for those.
- If you see any unwanted third‑party badges or scripts, remove the related `<script>` tags from `index.html` and commit again.
- `404.html` is provided for nicer broken-link handling.
```

